import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


@pytest.mark.usefixtures("driver")
class TestSeleniumPlayground:

    @pytest.mark.order(1)
    def test_simple_form_demo(self, driver):
        driver.get("https://testmuai.com/selenium-playground/simple-form-demo")

        message = "Welcome to TestMu AI"

        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.ID, "user-message"))
        ).send_keys(message)

        driver.find_element(By.ID, "showInput").click()

        displayed = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.ID, "message"))
        ).text

        assert displayed == message

    @pytest.mark.order(2)
    def test_checkbox_demo(self, driver):
        driver.get("https://testmuai.com/selenium-playground/checkbox-demo")

        checkbox = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.ID, "isAgeSelected"))
        )

        checkbox.click()

        success = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.ID, "txtAge"))
        ).text

        assert success == "Success - Check box is checked"